package com.michael.cookies;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookiesSample
 */
@WebServlet("/CookiesSampleRes")
public class CookiesSampleRes extends HttpServlet {

	private static final long serialVersionUID = 2882884164629631581L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CookiesSampleRes() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ex : Cookie cookie = new Cookie("key","value");
				Cookie firstName = new Cookie("first_name", request.getParameter("first_name"));
				Cookie lastName = new Cookie("last_name", request.getParameter("last_name"));
				firstName.setMaxAge(60); // �]�w cookies �O�d���ɶ��h��
				lastName.setMaxAge(60); // �]�w cookies �O�d���ɶ��h��
				response.addCookie(firstName); // �N���[�J�� http header ��
				response.addCookie(lastName); // �N���[�J�� http header ��
				
				response.getWriter().append("Served at: ").append(request.getContextPath());
				//request.getRequestDispatcher("/CookiesSampleReq").forward(request, response);
				//request.getRequestDispatcher("http://localhost:8080/servletLearn/CookiesSampleReq").forward(request, response);
				//return;
				response.sendRedirect("http://localhost:8080/servletLearn/CookiesSampleReq");
	}

}
