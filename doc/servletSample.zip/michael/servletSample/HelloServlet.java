package com.michael.servletSample;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloServlet extends HttpServlet {
	
	private static final long serialVersionUID = -7760694672768203289L;
	private String message;
	
	public void init() {
		  message = "Test Page!!";
		  System.out.println("��l��");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//�]�m response �����e����
		response.setContentType("text/html");
		
		
		System.out.println(message);

		// ��ڪ� logic 
		PrintWriter out = response.getWriter();
		out.println("<h1>" + message + "</h1>");
	}

	public void destroy() {
		
		System.out.println("����");
	}
}
