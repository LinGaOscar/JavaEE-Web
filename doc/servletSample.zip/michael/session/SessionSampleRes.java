package com.michael.session;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionSampleRes
 */
@WebServlet("/SessionSampleRes")
public class SessionSampleRes extends HttpServlet {

	private static final long serialVersionUID = 4168888830062699501L;

	// http://localhost:8080/servletLearn/SessionSampleRes
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SessionSampleRes() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cookie cookie = null;
		Cookie[] cookies = null;
		cookies = request.getCookies();

		if (cookies != null) {
			response.getWriter().append("<h2> Found Cookies Name and Value</h2><br>");
			for (int i = 0; i < cookies.length; i++) {
				cookie = cookies[i];
				if ((cookie.getName()).compareTo("first_name") == 0) {
					cookie.setMaxAge(0);
					response.addCookie(cookie);
					System.out.println("已刪除的 cookie：" + cookie.getName());
				}
			}
		} else {
			response.getWriter().append("<h2>No cookies founds</h2>");
		}

		HttpSession session = request.getSession(true);
		System.out.println("獲取到的Session 為 ： " + session.getClass().getName());

		session.setMaxInactiveInterval(1000 * 5);
		int time = session.getMaxInactiveInterval();
		System.out.println("Session的有效期 為 ： " + time);

		long createTime = session.getCreationTime();// 返回long
		Date createDate = new Date(createTime);

		System.out.println("Session建立的時間為 ： " + createDate);

		session.setAttribute("first_name", request.getParameter("first_name"));
		session.setAttribute("last_name", request.getParameter("last_name"));
		String firstName = (String) session.getAttribute("first_name");
		String lastName = (String) session.getAttribute("last_name");
		System.out.println("Session中放置的資料   firstName ： " + firstName + ", lastName = " + lastName);

		response.getWriter().append("Served at: ").append(request.getContextPath());
		// request.getRequestDispatcher("/SessionSampleReq").forward(request, response);
		response.sendRedirect("http://localhost:8080/servletLearn/SessionSampleReq");
	}

}
